package pk.edu.uaf.linkify.Utils;

public final class AppConstant {

    public static final int OFFER_CASE_CALL = 1;
    public static final int OFFER_CASE_MESSAGE = 2;
    public static final int MY_PERMISSIONS_REQUEST_READ_CONTACTS = 3;
    public static final int GALLERY_REQUEST_CODE = 4;
}
